package first;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class EmployeeServlet extends HttpServlet
{
	Connection con;
	public void init() throws ServletException
	{
		try
		{
			ServletContext sc = getServletContext();
			String driver = sc.getInitParameter("driver");
			String url = sc.getInitParameter("url");
			String user = sc.getInitParameter("user");
			String password = sc.getInitParameter("password");
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, password);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void destroy() {
		try
		{
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try
		{
			
			int random = new Random().nextInt(100);
			String name = request.getParameter("name");
			String addrs = request.getParameter("addr");
			String gender = request.getParameter("gender");
			String sal1 = request.getParameter("sal");
			String dob1 = request.getParameter("dob");
			Double sal = Double.parseDouble(sal1);

			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");

            // Parse the HTML date string to a java.util.Date object
            Date utilDate = inputFormat.parse(dob1);
            
            // Define the output format for Oracle SQL date
            SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yy");
            String s = outputFormat.format(utilDate);
  			PreparedStatement pst = con.prepareStatement("INSERT INTO EMPLOYEE VALUES(?,?,?,?,?,?)");
		    pst.setInt(1, random);
			pst.setString(2, name);
			pst.setString(3, addrs);
			pst.setString(4, gender);
			pst.setDouble(5, sal);
			pst.setString(6, s);
			pst.executeUpdate();
			RequestDispatcher rd = request.getRequestDispatcher("/empList.jsp");
			rd.forward(request, response);
		}
		catch(Exception e)
		{
			PrintWriter pw = response.getWriter();
			pw.println("<html> <body> <center>");
			pw.println("<h1>Data is not inserted Please Fill form Correctly</h1>");
			pw.println("</center></body></html>");
		}
	}
}