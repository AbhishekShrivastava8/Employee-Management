package first;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class EmpListServlet extends HttpServlet {

	Connection con;

	public void init() throws ServletException {
		try {
			ServletContext sc = getServletContext();
			String driver = sc.getInitParameter("driver");
			String url = sc.getInitParameter("url");
			String user = sc.getInitParameter("user");
			String password = sc.getInitParameter("password");
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void destroy() {
		try {
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String eid = request.getParameter("delete");
		try {
			PreparedStatement pst = con.prepareStatement("DELETE FROM EMPLOYEE WHERE EMPLOYEEID=?");
			pst.setString(1, eid);
			pst.executeUpdate();
			ResultSet rs = pst.executeQuery("SELECT * FROM EMPLOYEE");
			if ((rs.next()) == true) {
				RequestDispatcher rd = request.getRequestDispatcher("/empShow.jsp");
				rd.forward(request, response);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}